class Peminjaman {
    int kodeBuku;
    int npmMahasiswa;

    public Peminjaman(int kodeBuku, int npmMahasiswa) {
        this.kodeBuku = kodeBuku;
        this.npmMahasiswa = npmMahasiswa;
    }
}

