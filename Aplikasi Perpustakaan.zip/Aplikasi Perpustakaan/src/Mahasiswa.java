class Mahasiswa {
    String nama;
    int npm;
    int jurusan;
    int tanggalPinjam;
    int tanggalKembali;
    int jumlahPinjam;

    public Mahasiswa(String nama, int npm, int jurusan, int tanggalPinjam) {
        this.nama = nama;
        this.npm = npm;
        this.jurusan = jurusan;
        this.tanggalPinjam = tanggalPinjam;
    }
}

