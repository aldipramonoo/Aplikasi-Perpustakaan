class Buku {
    int kode;
    String judul;
    String pengarang;
    int tahunTerbit;

    public Buku(int kode, String judul, String pengarang, int tahunTerbit) {
        this.kode = kode;
        this.judul = judul;
        this.pengarang = pengarang;
        this.tahunTerbit = tahunTerbit;
    }
}

